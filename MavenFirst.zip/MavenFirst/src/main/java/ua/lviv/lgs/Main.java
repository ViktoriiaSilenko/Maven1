package ua.lviv.lgs;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {

	public static void main(String[] args) {
		SessionFactory factoty = new AnnotationConfiguration().configure()
				.addAnnotatedClass(Author.class).addAnnotatedClass(Book.class)
				.buildSessionFactory();
		Session session = factoty.openSession();
		Author a = new Author("Hemin", 23);
		// a.setId(1);
		// Book b = new Book("Hobbit", (Author) session.get(Author.class, 5));
		// Book b1 = new Book("LOTR", (Author) session.get(Author.class, 5));
		session.beginTransaction();
		List<Author> authirs = session.createQuery("From Author a where a.name = :name")
				.setParameter("name", "Hemin").list();
		Author forDelete = authirs.get(0);
//		session.delete(session.get(Author.class, 6));
		session.delete(forDelete);
		// session.save(b);
		// session.save(b1);
		session.getTransaction().commit();
		session.close();
		factoty.close();

	}

}
